# -*- coding: utf-8 -*-
from . import copy_verification_lines
